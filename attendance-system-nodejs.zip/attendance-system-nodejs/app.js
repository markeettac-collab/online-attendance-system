const express = require("express");
const session = require("express-session");
const sqlite3 = require("sqlite3").verbose();
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = path.join(__dirname, "database.db");

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  secret: process.env.SESSION_SECRET || "change-this-session-secret-before-deployment",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax" }
}));

const db = new sqlite3.Database(DB_PATH);
const run = (sql, params = []) => new Promise((resolve, reject) =>
  db.run(sql, params, function (err) { if (err) reject(err); else resolve(this); }));
const get = (sql, params = []) => new Promise((resolve, reject) =>
  db.get(sql, params, (err, row) => err ? reject(err) : resolve(row)));
const all = (sql, params = []) => new Promise((resolve, reject) =>
  db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows)));

async function initDb() {
  await run(`CREATE TABLE IF NOT EXISTS Instructors (
    instructor_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL
  )`);
  await run(`CREATE TABLE IF NOT EXISTS Courses (
    course_id INTEGER PRIMARY KEY AUTOINCREMENT,
    course_name TEXT NOT NULL, instructor_id INTEGER,
    FOREIGN KEY (instructor_id) REFERENCES Instructors(instructor_id)
  )`);
  await run(`CREATE TABLE IF NOT EXISTS Students (
    student_id INTEGER PRIMARY KEY AUTOINCREMENT, student_name TEXT NOT NULL
  )`);
  await run(`CREATE TABLE IF NOT EXISTS Attendance (
    attendance_id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER, course_id INTEGER, date TEXT NOT NULL,
    time_slot TEXT NOT NULL, status TEXT NOT NULL,
    FOREIGN KEY (student_id) REFERENCES Students(student_id),
    FOREIGN KEY (course_id) REFERENCES Courses(course_id)
  )`);

  const teacher = await get("SELECT instructor_id FROM Instructors WHERE email = ?", ["ali@email.com"]);
  if (!teacher) {
    const result = await run(
      "INSERT INTO Instructors (name, email, password) VALUES (?, ?, ?)",
      ["Sir Ali", "ali@email.com", "12345"]
    );
    await run("INSERT INTO Courses (course_name, instructor_id) VALUES (?, ?)", ["Python Programming", result.lastID]);
    await run("INSERT INTO Students (student_name) VALUES (?)", ["Zainab"]);
    await run("INSERT INTO Students (student_name) VALUES (?)", ["Ahmed"]);
  }
}

const slots = ["08:00 AM - 10:00 AM", "10:00 AM - 12:00 PM", "12:00 PM - 02:00 PM", "02:00 PM - 04:00 PM"];

app.get("/", (req, res) => res.render("index"));

app.get("/teacher/login", (req, res) => res.render("teacher_login"));
app.post("/teacher/login", async (req, res, next) => {
  try {
    const email = (req.body.email || "").trim();
    const password = (req.body.password || "").trim();
    const teacher = await get(
      "SELECT instructor_id, name FROM Instructors WHERE email = ? AND password = ?",
      [email, password]
    );
    if (!teacher) return res.status(401).send('<h1>Error: Invalid Email or Password!</h1><br><a href="/teacher/login">Go Back</a>');
    req.session.teacherId = teacher.instructor_id;
    req.session.teacherName = teacher.name;
    res.redirect("/teacher/dashboard");
  } catch (err) { next(err); }
});

app.get("/teacher/dashboard", async (req, res, next) => {
  if (!req.session.teacherId) return res.redirect("/teacher/login");
  try {
    const students = await all("SELECT student_id, student_name FROM Students ORDER BY student_id");
    const course = await get(
      "SELECT course_id, course_name FROM Courses WHERE instructor_id = ? ORDER BY course_id LIMIT 1",
      [req.session.teacherId]
    );
    res.render("teacher_dash", { slots, students, course, teacherName: req.session.teacherName });
  } catch (err) { next(err); }
});

app.post("/teacher/dashboard", async (req, res, next) => {
  if (!req.session.teacherId) return res.redirect("/teacher/login");
  try {
    const date = (req.body.date || "").trim();
    const slot = (req.body.slot || "").trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !slots.includes(slot)) {
      return res.status(400).send('<h1>Invalid date or class session.</h1><a href="/teacher/dashboard">Go Back</a>');
    }
    const course = await get(
      "SELECT course_id FROM Courses WHERE instructor_id = ? ORDER BY course_id LIMIT 1",
      [req.session.teacherId]
    );
    if (!course) return res.status(400).send('<h1>No course is assigned to this teacher.</h1><a href="/teacher/dashboard">Go Back</a>');

    const students = await all("SELECT student_id FROM Students ORDER BY student_id");
    await run("BEGIN TRANSACTION");
    try {
      for (const student of students) {
        const status = req.body[`status_${student.student_id}`] === "Absent" ? "Absent" : "Present";
        const existing = await get(
          "SELECT attendance_id FROM Attendance WHERE student_id = ? AND course_id = ? AND date = ? AND time_slot = ?",
          [student.student_id, course.course_id, date, slot]
        );
        if (existing) {
          await run("UPDATE Attendance SET status = ? WHERE attendance_id = ?", [status, existing.attendance_id]);
        } else {
          await run(
            "INSERT INTO Attendance (student_id, course_id, date, time_slot, status) VALUES (?, ?, ?, ?, ?)",
            [student.student_id, course.course_id, date, slot, status]
          );
        }
      }
      await run("COMMIT");
    } catch (err) {
      await run("ROLLBACK");
      throw err;
    }
    res.redirect("/teacher/dashboard");
  } catch (err) { next(err); }
});

app.get("/student/login", (req, res) => res.render("student_login"));
app.post("/student/login", async (req, res, next) => {
  try {
    const studentId = Number((req.body.student_id || "").trim());
    const studentName = (req.body.student_name || "").trim();
    const requestedCourse = (req.body.course_name || "").trim();
    const requestedInstructor = (req.body.instructor_name || "").trim();

    const student = await get("SELECT student_id, student_name FROM Students WHERE student_id = ?", [studentId]);
    if (!student || student.student_name.toLowerCase() !== studentName.toLowerCase()) {
      return res.status(404).send('<h1>Error: No Record Found for this Student ID!</h1><br><a href="/student/login">Go Back</a>');
    }

    const history = await all(
      `SELECT A.date, A.time_slot, A.status, C.course_name, I.name AS instructor_name
       FROM Attendance A
       JOIN Courses C ON C.course_id = A.course_id
       LEFT JOIN Instructors I ON I.instructor_id = C.instructor_id
       WHERE A.student_id = ? ORDER BY A.date DESC, A.time_slot`,
      [studentId]
    );
    if (!history.length) {
      return res.status(404).send('<h1>Error: No Record Found for this Student ID!</h1><br><a href="/student/login">Go Back</a>');
    }

    const course = history[0].course_name;
    const instructor = history[0].instructor_name || "Not assigned";
    if (requestedCourse.toLowerCase() !== course.toLowerCase() ||
        requestedInstructor.toLowerCase() !== instructor.toLowerCase()) {
      return res.status(400).send('<h1>Error: Student, course, or instructor details do not match!</h1><br><a href="/student/login">Go Back</a>');
    }

    const presents = history.filter(row => row.status === "Present").length;
    const percentage = (presents / history.length) * 100;
    const aiInsights = await getAiInsights(student.student_name, percentage, history.length, presents);
    res.render("student_hist", {
      history, name: student.student_name, course, instructor, ai_insights: aiInsights
    });
  } catch (err) { next(err); }
});

async function getAiInsights(studentName, percentage, total, presents) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey) {
    try {
      const prompt = `You are an AI Academic Assistant. A student named ${studentName} has attendance ${percentage.toFixed(1)}% (${presents} present out of ${total} classes). Give brief motivating professional feedback in 2-3 sentences in Roman Urdu or simple English. If below 80%, give gentle advice; otherwise appreciate them.`;
      const response = await fetch(
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + encodeURIComponent(apiKey),
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] })
        }
      );
      if (response.ok) {
        const data = await response.json();
        const answer = data.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim();
        if (answer) return answer;
      }
    } catch (error) {
      console.error("Gemini API unavailable:", error.message);
    }
  }
  return percentage >= 80
    ? `Excellent consistency, ${studentName}! Your attendance rate is ${percentage.toFixed(1)}%. Keep it up!`
    : `Warning ${studentName}: Your attendance is ${percentage.toFixed(1)}%. You need to improve your regularity to avoid academic penalties.`;
}

app.get("/logout", (req, res) => {
  req.session.destroy(() => res.redirect("/"));
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).send("Something went wrong. Check the terminal for details.");
});

initDb().then(() => {
  app.listen(PORT, () => console.log(`Attendance system running at http://localhost:${PORT}`));
}).catch(err => {
  console.error("Database initialization failed:", err);
  process.exit(1);
});

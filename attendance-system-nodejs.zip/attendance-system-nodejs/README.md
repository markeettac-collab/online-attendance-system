# Attendance Management System (Node.js Backend)

The original HTML page layouts and inline styling are retained. The Flask/Python backend has been replaced with Node.js + Express, EJS and SQLite. The supplied `database.db` is included.

## Requirements
- Node.js 18 or newer (Node 20 LTS recommended)
- Internet connection for the first `npm install`

## Run on Windows / VS Code
1. Extract this ZIP.
2. Open the extracted `node-attendance-system` folder in VS Code.
3. Open Terminal > New Terminal.
4. Run:

```powershell
npm install
npm start
```

5. Open `http://localhost:3000` in Chrome.

## Default teacher login
- Email: `ali@email.com`
- Password: `12345`

The included database already contains the sample teacher, course and students. Student report login uses the student ID and name from the database, plus the course and instructor recorded for that student's attendance.

## Optional Gemini AI feedback
The report works without an API key and shows built-in attendance feedback. To enable Gemini AI feedback in PowerShell for the current terminal:

```powershell
$env:GEMINI_API_KEY="YOUR_GEMINI_API_KEY"
npm start
```

Do not publish your API key or put it directly in `app.js`.

## Notes
- Attendance is saved in `database.db`.
- Submitting attendance again for the same student, date, course and time slot updates that record instead of creating a duplicate.
- Keep `database.db` in the project root.
- The UI layout, labels, colors and inline styles are preserved from the supplied project.
